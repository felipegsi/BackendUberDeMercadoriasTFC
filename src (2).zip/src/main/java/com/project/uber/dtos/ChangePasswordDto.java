package com.project.uber.dtos;

public record ChangePasswordDto(String oldPassword, String newPassword) {
}
