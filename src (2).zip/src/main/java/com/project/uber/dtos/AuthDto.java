package com.project.uber.dtos;

public record AuthDto(String email, String password) {
}