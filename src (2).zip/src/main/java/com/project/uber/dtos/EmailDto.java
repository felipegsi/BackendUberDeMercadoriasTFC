package com.project.uber.dtos;

public record EmailDto(String to, String subject, String text) {
}
